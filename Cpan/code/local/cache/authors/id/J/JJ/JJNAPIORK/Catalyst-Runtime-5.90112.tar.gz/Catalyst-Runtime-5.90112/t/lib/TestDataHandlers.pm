package TestDataHandlers;

use Catalyst;

__PACKAGE__->config(
  'Controller::Root', { namespace => '' }
);

__PACKAGE__->setup;

package Overloading::RoleConsumesOverloads;

use Moose::Role;

with 'Overloading::RoleWithOverloads';

1;

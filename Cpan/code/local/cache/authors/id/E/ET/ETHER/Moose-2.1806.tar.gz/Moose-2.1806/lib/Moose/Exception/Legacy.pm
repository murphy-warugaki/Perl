package Moose::Exception::Legacy;
our $VERSION = '2.1806';

use Moose;
extends 'Moose::Exception';

1;

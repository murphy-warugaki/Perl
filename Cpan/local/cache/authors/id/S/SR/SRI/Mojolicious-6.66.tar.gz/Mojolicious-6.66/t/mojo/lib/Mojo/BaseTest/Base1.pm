package Mojo::BaseTest::Base1;
use Mojo::Base -base;

has 'foo';

1;

package Moose::Exception::OperatorIsRequired;
our $VERSION = '2.1804';

use Moose;
extends 'Moose::Exception';
with 'Moose::Exception::Role::ParamsHash';

has 'class' => (
    is       => 'ro',
    isa      => 'Str',
    required => 1
);

sub _build_message {
    "operator is required";
}

1;

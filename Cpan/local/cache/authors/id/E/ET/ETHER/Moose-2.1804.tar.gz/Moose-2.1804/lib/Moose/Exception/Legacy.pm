package Moose::Exception::Legacy;
our $VERSION = '2.1804';

use Moose;
extends 'Moose::Exception';

1;
